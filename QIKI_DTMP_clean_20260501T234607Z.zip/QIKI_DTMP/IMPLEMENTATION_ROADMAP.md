# QIKI_DTMP — Implementation Roadmap (обновлено 2025-09-27)

> HISTORICAL/REFERENCE ONLY (NOT CANON) / ИСТОРИЯ/СПРАВКА (НЕ КАНОН)  
> Канон приоритетов (что сейчас важно) живёт только в `~/MEMORI/ACTIVE_TASKS_QIKI_DTMP.md`.  
> Этот файл не является «Now/Next/Backlog» и не должен использоваться как источник текущих приоритетов.  
> Marked: 2026-01-22
> Update (2026-01-26): `q-sim-radar` удалён; `q-sim-service` публикует radar frames; docker-compose без `q-sim-radar`.

## 0. Метаданные
- **Дата создания:** 2025-07-30  
- **Последняя ревизия:** 2025-09-27 (Stage 1 LR/SR foundation)  
- **Текущая готовность:** ~93%  
- **Цель:** ≥95% Production-ready цифровой двойник

## 1. Архитектурное видение
- **Document-First / Contract-Oriented:** protobuf и AsyncAPI остаются единым источником правды.
- **Evolutionary Design:** Bot → Ship → Station → Fleet; текущий фокус — Bot + Radar v1.
- **Надёжность:** приоритет у health-check, JetStream dedup, контролируемых пайплайнов.

## 2. Текущее состояние (2025-09-21)

| Компонент | Готовность | Статус | Примечание |
|-----------|------------|--------|------------|
| Protocol Buffers | 100% | ✅ Radar v1 (`SensorType.RADAR`, `GetRadarFrame`). | Контракты синхронизированы с кодом. |
| Generated Stubs & Shim | 100% | ✅ Работают в docker-образах. | `generated/`, `radar/`, `*_pb2.py` shim. |
| Services (q-sim-service, faststream-bridge) | 88% | ⚠️ Требуется продвинутый трекинг/визуализация. | LR/SR-разделение внедрено, union-топик сохранён. |
| Q-Core Agent | 85% | ⚠️ Tick-цикл стабилен, UI/алерты отсутствуют. | |
| Scripts & Automation | 92% | ✅ docker-compose Phase 1 + `nats-js-init` (фиксы 2025-09-18 исключают падения при инициализации). | |
| Testing | 80% | ⚠️ Unit + integration (radar + Stage 0) зелёные; нет нагрузочных сценариев. | |
| CI/CD | 40% | 🛠️ `ruff`, `mypy`, `pytest`, `buf lint`; добавлен smoke-тест фреймворк; coverage/AsyncAPI отсутствуют. | |
| Documentation | 75% | 🛠️ README/ARCHITECTURE/RESTART обновлены, Stage 0 полностью документирован, остальные синхронизируются. | |
| Observability | 60% | ✅ WorldModel экспортирует `qiki_agent_*` метрики; добавлен мониторинг JetStream лагов. | JetStream/OTel ещё впереди. |
| Configuration Management | 90% | ✅ BotSpec с валидатором и генератором конфигов. | |
| Event Standardization | 85% | ✅ CloudEvents-хедеры для всех сообщений. | |
| Audit & Logging | 80% | ✅ Сервис регистратора событий с кодами 1xx-9xx. | |
| Radar Visualization | 10% | 🚧 UI/алерты не реализованы. | |

### Устранённые блокеры
- Импорты generated stubs (2025-08-06) + shim-пакеты (`radar/`, `*_pb2.py`).
- Права на скрипты (`run_qiki_demo.sh`, `run_tests_and_lint.sh`).
- CI переменные (`q_core_agent_path`).
- Dockerfile.dev — устанавливает `buf`; Phase 1 docker-compose содержит radar pipeline.
- `tools/js_init.py` (2025-09-18) — числовые параметры JetStream, идемпотентное создание consumer’ов, контейнерный запуск без ошибок.
- Stage 0 Implementation (2025-09-21) — завершены все задачи Stage 0: BotSpec, CloudEvents, JetStream monitoring, Registrar, smoke tests.
- Stage 1 LR/SR foundation (2025-09-27) — внедрены `RadarRangeBand`, новые топики `frames.lr`/`tracks.sr`, `x-range-band`-хедеры, порог `radar.sr_threshold_m`, интеграционный тест `test_radar_lr_sr_topics.py` зелёный.

### Новые риски / TODO
- Продвинутый stateful трекинг, учёт IFF/транспондера, алерты.
- Визуализация радара (требования PDF) + операторские панели.
- Метрики (Prometheus/OTel), нагрузочные тесты JetStream.
- Автоматизация AsyncAPI публикации, coverage-отчёты в CI.
- Интеграция smoke-тестов в CI/CD pipeline.
- Документирование результатов (CLAUDE_MEMORY, PROJECT_MAP и др.).

## 3. План выполнения

### Phase 1 — Базовая интеграция (ЗАВЕРШЕНО)
- ✔ Исправлены generated imports, настроены скрипты и CI.
- ✔ docker-compose.phase1.yml включает `nats`, `q-sim-service`, `faststream-bridge`, `qiki-dev`, `nats-js-init`.
- ✔ gRPC `GetRadarFrame` реализован, Pydantic модели и конвертеры обновлены.
- ✔ JetStream stream `QIKI_RADAR_V1`, durable consumers (`radar_frames_pull`, `radar_tracks_pull`).
- ✔ Интеграционные тесты радара проходят внутри контейнера `qiki-dev`.

### Phase 2 — Усиление качества (ЗАВЕРШЕНО)
| ID | Задача | Статус |
|----|--------|--------|
| Q2.1 | Финализировать документацию (CLAUDE_MEMORY, CURRENT_STATE, ROADMAP, PROJECT_MAP). | ✅ завершено (2025-09-20) |
| Q2.2 | Автоматизировать AsyncAPI + coverage в CI. | ⏳ |
| Q2.3 | Подготовить нагрузочные сценарии JetStream (fps, backpressure). | ⏳ |
| Q2.4 | Добавить наблюдаемость (Prometheus/metrics). | ✅ завершено (2025-09-21) |
| Q2.5 | Реализовать Stage 0 (BotSpec, CloudEvents, Registrar, smoke tests). | ✅ завершено (2025-09-21) |

### Phase 3 — Функциональное развитие (Backlog)
| ID | Направление | Описание |
|----|-------------|----------|
| F3.1 | Трекинг и классификация | Реализовать stateful-агрегацию, фильтры, учёт IFF/транспондера. |
| F3.2 | Визуализация радара | Табличное/графическое представление, алерты, операторский UI (см. PDF). |
| F3.3 | Operator Console | Расширить FastStream/CLI для контроля радара и команд. |
| F3.4 | Multi-sensor integration | Интегрировать радар в общий поток `SensorReading` на стороне агента и клиентов. |

## 4. Метрики успеха
- Интеграционные тесты радара выполняются в CI (включая `test_radar_lr_sr_topics.py`).
- Метрики JetStream (latency, backlog, drop rate) мониторятся и имеют алерты.
- UI/операторский сценарий демонстрирует кадры/треки в реальном времени.
- Документация не старше 7 дней (см. DOCUMENTATION_UPDATE_PROTOCOL.md).
- Smoke-тесты проходят успешно, подтверждая работоспособность всех компонентов.
- Все компоненты Stage 0 интегрированы и функционируют корректно.

## 5. Связанные документы
- [RADAR.md](RADAR.md) — полное досье интеграции радара.
- [README.md](README.md) — обновлённый обзор и запуск Phase 1.
- [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) — диаграммы и health.
- [docs/RESTART_CHECKLIST.md](docs/RESTART_CHECKLIST.md) — пошаговый рестарт.
- [DOCUMENTATION_UPDATE_PROTOCOL.md](DOCUMENTATION_UPDATE_PROTOCOL.md) — регламент обновления документации.
- [docs/stage0_actual_plan.md](docs/stage0_actual_plan.md) — план реализации Stage 0.
- [journal/2025-09-21_Stage0-Implementation/task.md](journal/2025-09-21_Stage0-Implementation/task.md) — полная документация реализации Stage 0.
