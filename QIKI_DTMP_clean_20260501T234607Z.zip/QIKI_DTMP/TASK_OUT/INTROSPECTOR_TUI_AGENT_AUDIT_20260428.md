# Introspector TUI Agent Audit

**Date:** 2026-04-28  
**Project:** QIKI_DTMP  
**Target:** `/home/sonra44/QIKI_DTMP/introspector`  
**Mode:** read-only multi-agent audit  
**Agents:** Structure Agent, TUI Logic Agent, Backend-to-TUI Implementation + Tests Agent  
**Result:** Introspector TUI is structurally usable, but needs a narrow contract/source-root hardening slice before larger UI expansion.

## 1. Executive Summary

Introspector TUI is not just background tooling. It is already a real operator console over the Introspector analyzer stack.

The current backend-to-TUI chain is clear:

```text
analyzer/app.py
  -> tui_client.py
  -> tui_operations.py
  -> tui_state.py / tui_render.py
  -> tui_app.py
  -> tests
```

The strongest current value:

- factual project scan;
- analyzer-backed schema/report;
- module overview and module findings;
- scan/enrichment panels;
- explicit degraded/provider state handling;
- tests around client, operations, state, app, API flow, report quality, and tmux smoke.

The strongest current risk:

- `Scan Project` can silently scan the Introspector package itself instead of the intended `QIKI_DTMP/src` unless `INTROSPECTOR_SOURCE_ROOT` or `--source-root` is explicit.

The best next implementation slice is not redesign. It is:

```text
Introspector TUI contract/source-root hardening
```

## 2. Structure Agent Result

### Scope

Read-only structural audit of `QIKI_DTMP/introspector`.

### Component Map

- SDK/source layer:
  - `src/project_introspector/scanner.py`
  - `src/project_introspector/models.py`
  - `src/project_introspector/schema_builder.py`
  - `src/project_introspector/emitter.py`
  - `src/project_introspector/runtime.py`
  - `src/project_introspector/llm*.py`
  - provider modules.

- Analyzer service:
  - `analyzer/app.py`
  - `analyzer/storage.py`
  - local SQLite + JSON mirror storage.

- TUI layer:
  - `tui_app.py`
  - `tui_client.py`
  - `tui_operations.py`
  - `tui_state.py`
  - `tui_models.py`
  - `tui_render.py`
  - `tui_text.py`

- Scripts:
  - `scripts/run_tui.sh`
  - `scripts/run_fresh_analyzer.sh`
  - `scripts/scan_project.py`
  - `scripts/enrich_modules.py`
  - `scripts/live_module_pass.py`
  - `scripts/tui_tmux_smoke.sh`
  - `scripts/clean_dev_artifacts.sh`
  - `scripts/export_bundle.sh`

- Tests:
  - `tests/test_tui_app.py`
  - `tests/test_tui_client.py`
  - `tests/test_tui_operations.py`
  - `tests/test_tui_state.py`
  - `tests/test_tui_api_flow.py`
  - `tests/test_tui_tmux_smoke.py`
  - `tests/test_report_quality.py`
  - storage/analyzer/script tests.

### Entrypoints

TUI:

```text
project-introspector-tui
scripts/run_tui.sh
python -m project_introspector.tui_app
```

Analyzer:

```text
scripts/run_fresh_analyzer.sh
uvicorn analyzer.app:app --host 127.0.0.1 --port 8015
```

Factual scan:

```text
scripts/scan_project.py
```

Enrichment:

```text
scripts/enrich_modules.py
scripts/live_module_pass.py
```

### Source / Generated Split

Source / commit-ready:

```text
src/project_introspector/**
analyzer/app.py
analyzer/storage.py
scripts/*.py
scripts/*.sh
tests/**
README.md
BASELINE.md
REPORT_QUALITY_PLAN.md
CHANGES.md
pyproject.toml
```

Generated/runtime/dev state:

```text
.venv/
build/
**/__pycache__/
.pytest_cache/
.mypy_cache/
.ruff_cache/
analyzer/data/analyzer.sqlite3*
analyzer/data/static/*.json
analyzer/data/runtime/*.json
analyzer/data/derived/*.json
tmp/**
```

### Structural Verdict

Structurally ready as an operator console over analyzer API.

Not a truth owner. It is an evidence/report surface.

## 3. TUI Logic Agent Result

### UI Entrypoint And State Model

Entrypoint:

```text
project-introspector-tui = project_introspector.tui_app:main
```

Main app:

```text
IntrospectorTuiApp
```

Important state fields:

```text
analyzer_status
schema
analysis_map
project_report
module_rows
selected_module_path
last_project_scan
last_live_pass
last_error
_running_actions
_action_feedback
compact_mode
filters/search state
```

### Main Display Provenance

| Displayed value | Source | Provenance | Risk |
|---|---|---|---|
| provider/configured/model/storage | `/llm/status` | provider/action readiness | not factual scan truth |
| schema/modules/files/symbols | `/schema/{project}` | factual schema | depends on current scan target |
| overview counts | schema + module rows + status | derived UI summary | can mix factual and enrichment health |
| module purpose/status/warnings | derived LLM/module artifacts | enrichment | not source-code truth |
| runtime counts | schema runtime event counts | runtime evidence | only as good as captured events |
| project report factual layer | `/report/{project}` | evidence report | good if source_root is correct |
| module findings | `/report.module_findings` | LLM enrichment provenance | must not become command authority |
| scan summary | `ops_project_scan_summary` | factual scan summary | source_root must be visible |
| live pass summary | `ops_live_pass_summary` | enrichment operation summary | provider-dependent |

### Action Mapping

| Action | Trigger | Behavior |
|---|---|---|
| Refresh Views | `r` / action | reloads status, schema, report, derived analyses, summaries |
| Refresh Status | button / `l` | reloads status/report/summaries, not full schema/module rows |
| Scan Project | button / `g` | runs `scripts/scan_project.py`, then refreshes factual layer |
| Run Enrichment Queue | button / `p` | gated by provider configured, runs enrichment scripts |
| Enrich Selected | button / `a` | gated by provider + selected module, reanalyzes one module |
| Search/filter | `/`, `s`, `d`, `w` | filters rows/findings |
| Language | `t` | labels/text only, not state semantics |

### TUI Logic Risks

- `Scan Project` name can mislead if source root resolves to `introspector/src` while operator expects `QIKI_DTMP/src`.
- `pending` enrichment means absent artifact, not necessarily queued work.
- Top status can mix provider readiness, runtime evidence, and enrichment counts too tightly.
- `Refresh Status` does not fully refresh schema/module rows.
- Provider availability can be stale until refresh.
- Old derived artifacts can sit beside new factual scan unless provenance/freshness is inspected.
- `static-only` and `no-runtime-evidence` runtime filters are semantically close and can confuse operators.
- `tui_render.py` has duplicate `render_module_rows` definitions; stable at runtime but risky for maintenance.
- Compact mode shows provider action hints even when provider is unavailable; action feedback handles it, but visible disabled state is weaker.

### TUI Logic Minimal Fix

Make scan source scope visible and testable.

Specifically:

- show resolved `source_root` before/after scan;
- ensure scan path cannot silently scan `introspector/src` when the operator intended `/home/sonra44/QIKI_DTMP/src`;
- add tests around this behavior.

## 4. Backend-to-TUI Implementation + Tests Agent Result

### Wiring Verdict

Implementation-ready for narrow TUI extensions.

There is a clean chain:

```text
analyzer endpoints
  -> IntrospectorTuiClient
  -> IntrospectorTuiOperations
  -> TUI state/render/app
  -> tests
```

### Endpoint -> Adapter -> UI Consumer Map

| Endpoint/source | Adapter | UI consumer | Existing tests | Gap |
|---|---|---|---|---|
| `/llm/status` | `fetch_status()` -> `AnalyzerStatus` | status panels, replay panels, provider action gating | present | malformed/missing configured/storage fields |
| `/schema/{project}` | `fetch_schema()` -> `ProjectSchema` | module rows, tree, runtime table, detail panels | present | empty schema / schema 404 after status OK |
| `/report/{project}` | `fetch_report()` raw dict | report block, project findings | present | missing scope/provenance/non-list findings |
| `/derived/{project}` | derived loaders | latest scan/live/module artifacts | present | corrupt payload/list unavailable/fallback ambiguity |
| `/llm/analyze/module` | `fetch_module_analysis()` | selected module enrichment/action feedback | partial | visible success/failure feedback |
| scan/live scripts | subprocess wrappers | replay panels/action feedback | present | pending/degraded replay panels |

### Existing Test Surface

- Unit/state:
  - `tests/test_tui_state.py`
  - `tests/test_tui_client.py`
  - `tests/test_tui_operations.py`

- Analyzer/API/report:
  - `tests/test_report_quality.py`
  - `tests/test_ops_status_and_api_artifacts.py`
  - `tests/test_tui_api_flow.py`
  - `tests/test_analyzer_integration.py`

- Textual app:
  - `tests/test_tui_app.py`

- Operational smoke:
  - `tests/test_tui_tmux_smoke.py`
  - `scripts/tui_tmux_smoke.sh`

### Coverage Gaps

Required missing proof areas:

- report missing fields;
- malformed module findings;
- absent provenance;
- corrupt derived payload;
- degraded module artifact render;
- live pass pending/degraded replay panel;
- provider state changing after TUI startup;
- source-root confusion around `Scan Project`;
- stale artifact versus new scan summary.

### Recommended Narrow Implementation Task

Do one small hardening slice:

```text
Introspector TUI contract/source-root hardening
```

Steps:

1. Add tests for partial/missing report + derived summary payloads.
2. Add tests for source_root visibility/resolution after scan.
3. Add tests for pending/degraded/missing-field states.
4. If tests show repeated brittleness, add a tiny typed adapter/normalizer for project report payloads.
5. Keep UI semantics unchanged.
6. Do not redesign.

Required test command before done:

```bash
pytest -q \
  tests/test_tui_client.py \
  tests/test_tui_operations.py \
  tests/test_tui_state.py \
  tests/test_report_quality.py \
  tests/test_ops_status_and_api_artifacts.py \
  tests/test_tui_api_flow.py \
  tests/test_tui_app.py
```

If visible layout/startup changes:

```bash
pytest -q tests/test_tui_tmux_smoke.py
```

## 5. Combined Assessment

### What is already good

- TUI has clear source modules.
- Analyzer/TUI split is reasonable.
- Factual scan and enrichment are separated.
- Provider-unconfigured path exists.
- Project report exposes `llm_is_truth_source=false`.
- Tests already cover substantial areas.
- tmux smoke exists.

### What is not good enough yet

- scan target scope can be ambiguous;
- report payload is too raw/untyped in TUI;
- missing-field/degraded/pending contracts need stronger tests;
- stale artifact freshness is not obvious enough;
- compact mode provider availability can be clearer;
- `/ops/status` exists but is not strongly wired into TUI consumer logic.

## 6. Decision

Do not redesign Introspector TUI now.

Do this next:

```text
TUI contract/source-root hardening slice
```

This is the smallest useful step because it prevents the exact class of operator confusion that matters most:

```text
I clicked Scan Project, but what project did it actually scan?
```

## 7. Next Practical Prompt

Use this prompt for the next implementation step:

```text
Ты Backend-to-TUI Implementation + Tests Agent для QIKI_DTMP/introspector.
Задача: выполнить узкий Introspector TUI contract/source-root hardening slice.
Не делать redesign.
Не менять смысл factual scan/enrichment.

Нужно:
1. Проверить текущий scan source_root path в TUI action flow.
2. Сделать так, чтобы resolved source_root был явно виден в Scan / Enrichment или replay/status panel.
3. Добавить тесты, что TUI не может молча выдать introspector/src за QIKI_DTMP/src, когда задан INTROSPECTOR_SOURCE_ROOT=/home/sonra44/QIKI_DTMP/src.
4. Добавить missing/degraded report payload tests, если изменение касается report rendering.
5. Прогнать targeted pytest по TUI client/operations/state/report/app.
6. Если меняется visible layout/startup, прогнать tmux smoke.

Вернуть:
- changed files;
- source field;
- UI mapping;
- tests run;
- remaining risks.
```
