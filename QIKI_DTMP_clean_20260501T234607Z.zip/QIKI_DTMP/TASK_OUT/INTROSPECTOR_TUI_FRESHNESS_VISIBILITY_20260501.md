# Introspector TUI Freshness Visibility

Date: 2026-05-01
Scope: `/home/sonra44/QIKI_DTMP/introspector`

## What changed

The Introspector TUI now shows freshness for module detail artifacts against the latest factual project scan timestamp.

Visible states:

- `current` / `актуален`: artifact `updated_at` is equal to or newer than project scan `scanned_at`.
- `stale` / `устарел`: artifact `updated_at` is older than project scan `scanned_at`.
- `unknown` / `неизвестно`: either timestamp is missing or malformed.

## Why

Derived enrichment artifacts are not QIKI truth. They are operator evidence/projection over factual scan state. If a derived artifact is older than the current scan, the TUI must not let it look silently current.

## Files changed

- `introspector/src/project_introspector/tui_render.py`
- `introspector/src/project_introspector/tui_app.py`
- `introspector/src/project_introspector/tui_text.py`
- `introspector/tests/test_tui_app.py`

## Verification

Run from `/home/sonra44/QIKI_DTMP/introspector`:

```bash
.venv/bin/python -m pytest -q \
  tests/test_tui_app.py \
  tests/test_tui_client.py \
  tests/test_tui_operations.py \
  tests/test_tui_state.py \
  tests/test_report_quality.py \
  tests/test_ops_status_and_api_artifacts.py \
  tests/test_tui_api_flow.py

.venv/bin/python -m ruff check \
  src/project_introspector/tui_render.py \
  src/project_introspector/tui_app.py \
  src/project_introspector/tui_text.py \
  tests/test_tui_app.py \
  tests/test_tui_client.py
```

Observed result:

- targeted pytest: passed
- ruff: passed

## Boundary

No broad TUI redesign was done. No QIKI runtime truth or analyzer storage contract was changed. This is a narrow operator visibility hardening slice.

## Next practical step

Run the TUI against a real analyzer state and visually confirm that selected module artifacts show one of: `current`, `stale`, or `unknown` in the module artifact panel.
