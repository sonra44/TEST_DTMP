# Handoff 2026-04-27 - LangGraph Introspector Evidence Bridge

## Current State

We completed the first LangGraph/OPUI bridge for `project-introspector`.

Important clarification from the user: they do **not** currently see Introspector in the web UI. The bridge exists in backend/state/normalizer code, but no browser/end-to-end OPUI visual smoke has been run yet. Do not claim the web screen visibly shows it until that smoke is performed.

## What Changed

In `/home/sonra44/langgraph_app`:

- `app/introspector_report.py`
  - New read-only loader for `GET /report/{project_name}`.
  - Defaults: `INTROSPECTOR_ANALYZER_URL=http://127.0.0.1:8015`, `INTROSPECTOR_PROJECT_NAME=INTROSPECTOR_DEMO`.
  - Env controls: `INTROSPECTOR_REPORT_ENABLED`, `INTROSPECTOR_REPORT_TIMEOUT_SECONDS`.
  - Produces compact packet with `authority=evidence_only`.
  - Degrades to `missing`, `unavailable`, `invalid`, or `disabled` without failing the graph.

- `app/graph.py`
  - `AppState` now has `introspector_report_*` fields.
  - `intake_task` initializes defaults.
  - `project_context_node` calls `load_introspector_report()` and adds compact `introspector_report` into `project_context_packet` for Nemo.
  - `approval_gate` interrupt payload exposes report fields.
  - Report does not set `approval_status`, `safe_to_proceed`, `judge_decision`, routing, or command authority.

- `app/operator_ui.py`
  - Adds `technical.introspector_report` to the OPUI server projection.

- `app/ui_normalizer.py`
  - Adds Introspector report lines into `normalized.report.evidence_basis` and `normalized.report.evidence_limits`.
  - Handles both normal and passthrough mode.

- `scripts/test_introspector_report.py`
  - New unit-style script for compacting a successful report and degrading transport failure.

- `scripts/test_analysis_flow.py`
  - Patches `load_introspector_report` in graph tests.
  - Verifies Nemo receives `project_context_packet.introspector_report.authority == evidence_only`.

- `scripts/test_operator_ui_approval_flow.py`
  - Verifies OPUI technical view carries `introspector_report`.
  - Verifies normalized report evidence includes Introspector report lines.

- `README.md`
  - Documents Introspector evidence bridge and env controls.

## Validation Done

Commands passed:

```bash
cd /home/sonra44/langgraph_app
python -m py_compile app/*.py scripts/test_introspector_report.py scripts/test_analysis_flow.py scripts/test_operator_ui_approval_flow.py scripts/test_ui_normalizer.py
for test_file in scripts/test_*.py; do python "$test_file"; done
```

Live degraded/ok check was performed:

```bash
cd /home/sonra44/QIKI_DTMP/introspector
ALLOW_DEGRADED_START=1 PYTHON_BIN=.venv/bin/python ./scripts/run_fresh_analyzer.sh
.venv/bin/python scripts/scan_project.py --project-name INTROSPECTOR_DEMO

cd /home/sonra44/langgraph_app
INTROSPECTOR_ANALYZER_URL=http://127.0.0.1:8015 INTROSPECTOR_PROJECT_NAME=INTROSPECTOR_DEMO python - <<'PY'
from app.introspector_report import load_introspector_report
r = load_introspector_report(timeout_seconds=2)
p = r["introspector_report_packet"]
print("status=", r["introspector_report_status"])
print("authority=", p.get("authority"))
print("modules_scanned=", p.get("factual", {}).get("modules_scanned"))
print("runtime_events=", p.get("runtime", {}).get("runtime_event_count"))
print("llm_is_truth_source=", p.get("llm_is_truth_source"))
print("limits=", ",".join(p.get("limits", [])))
PY
```

Observed result after scan:

```text
status= ok
authority= evidence_only
modules_scanned= 29
runtime_events= 0
llm_is_truth_source= False
limits= runtime_absent,enrichment_absent
```

Before scan the loader returned `missing/evidence_only`, which is expected.

Cleanup verified:

- Analyzer stopped.
- `ss -ltnp 'sport = :8015'` showed no listener.
- `/home/sonra44/QIKI_DTMP/introspector/analyzer/data` and `/home/sonra44/QIKI_DTMP/introspector/tmp` contain only `.gitkeep`.

## Internet Check Used

- LangGraph interrupts docs: `interrupt()` pauses graph execution and resumes with `Command(resume=...)` using thread/checkpoint state. This supports keeping human approval as the authority boundary.
- LangGraph graph/state docs: graph state schema is explicit, so `introspector_report_*` fields were added to `AppState` instead of using implicit ad-hoc state.

## Sovereign Memory Proof

Saved and recalled:

- `STATUS` id `4006`
- `TODO_NEXT` id `4007`
- `DECISIONS` id `4008`

Earlier Introspector/TUI proof:

- `STATUS` id `4003`
- `TODO_NEXT` id `4004`
- `DECISIONS` id `4005`

## Current User Correction

User asked: "А давно у нас интро спектр веб интерфейсе или я что-то путаю."

Answer given: they do not see Introspector in web UI because there is no standalone Introspector web UI. The new bridge only makes Introspector report evidence available to `langgraph_app` backend/OPUI projection. User corrected: "Нет, я не вижу его."

Interpretation: next work must not assume visible web UI is done. It must perform and, if needed, implement the actual OPUI/browser display.

## Immediate Next Step

Run an end-to-end OPUI/browser smoke with analyzer running and a task referencing Introspector:

1. Start Introspector analyzer on `8015`.
2. Run factual scan for `INTROSPECTOR_DEMO`.
3. Start LangGraph backend and OPUI web server.
4. Submit a task like:

```text
Сравни состояние introspector по отчёту и текущей задаче, дай план без выполнения
```

5. Verify before approval that:

- OPUI report/evidence area visibly includes Introspector report evidence lines.
- `approval_pending` remains true and human-only.
- Report evidence does not auto-approve or change `safe_to_proceed`.

If the visible OPUI does not show the report evidence clearly, implement a small dedicated OPUI block for `technical.introspector_report`, preferably in details or report area, still marked as evidence-only.

## Do Not Claim

Do not claim "Introspector is in web UI" until the browser/OPUI smoke proves it visually.

Do not claim provider-backed module findings are populated. Current live proof was factual-only/degraded:

- `runtime_events=0`
- `enrichment_absent`
- no provider-backed findings

## Useful Commands

```bash
cd /home/sonra44/QIKI_DTMP/introspector
ALLOW_DEGRADED_START=1 PYTHON_BIN=.venv/bin/python ./scripts/run_fresh_analyzer.sh
.venv/bin/python scripts/scan_project.py --project-name INTROSPECTOR_DEMO
./scripts/clean_dev_artifacts.sh

cd /home/sonra44/langgraph_app
python scripts/test_introspector_report.py
python scripts/test_analysis_flow.py
python scripts/test_operator_ui_approval_flow.py
python scripts/test_ui_normalizer.py
for test_file in scripts/test_*.py; do python "$test_file"; done
GRAPH_API_BASE_URL=http://127.0.0.1:2047 python scripts/run_operator_ui.py --port 8092
```

## File List For Resume

Primary files:

- `/home/sonra44/langgraph_app/app/introspector_report.py`
- `/home/sonra44/langgraph_app/app/graph.py`
- `/home/sonra44/langgraph_app/app/operator_ui.py`
- `/home/sonra44/langgraph_app/app/ui_normalizer.py`
- `/home/sonra44/langgraph_app/scripts/test_introspector_report.py`
- `/home/sonra44/langgraph_app/scripts/test_analysis_flow.py`
- `/home/sonra44/langgraph_app/scripts/test_operator_ui_approval_flow.py`
- `/home/sonra44/langgraph_app/README.md`

Related Introspector files from previous slice:

- `/home/sonra44/QIKI_DTMP/introspector/src/project_introspector/report_quality.py`
- `/home/sonra44/QIKI_DTMP/introspector/analyzer/app.py`
- `/home/sonra44/QIKI_DTMP/introspector/src/project_introspector/tui_app.py`
- `/home/sonra44/QIKI_DTMP/introspector/src/project_introspector/tui_render.py`
- `/home/sonra44/QIKI_DTMP/introspector/src/project_introspector/tui_state.py`
- `/home/sonra44/QIKI_DTMP/introspector/src/project_introspector/tui_text.py`

