# QIKI Freshness Threshold Ownership Spec

**Date:** 2026-04-28  
**Project:** QIKI_DTMP  
**Scope:** read-only design/spec pass before implementation  
**Task:** `TASKS/TASK_20260330_qiki_freshness_threshold_ownership.md`  
**Status:** proposed ownership contract; no runtime/code behavior changed

## 1. Purpose

This spec fixes the current ambiguity around freshness thresholds used by QIKI reasoning.

The goal is not to change gameplay behavior. The goal is to make ownership explicit before any code move:

- which layer owns data freshness decisions;
- which thresholds are QIKI legality/trust gates;
- which thresholds are only ORION V operator projection;
- which timings are ACK/procedure/effect wait timeouts and not data freshness.

## 2. Current finding

The split ownership is real and code-backed.

QIKI reasoning currently uses two different threshold ownership paths:

1. service-local constants inside `qiki_orion_intents_service.py`:
   - `_COMMS_STALE_AFTER_S = 3.0`
   - `_COMMS_EXPIRE_AFTER_S = 12.0`
   - `_IMU_STALE_AFTER_S = 2.5`
   - `_IMU_EXPIRE_AFTER_S = 10.0`
   - `_RESUME_OBJECTIVE_STALE_AFTER_S = 90.0`

2. ad-hoc environment reads inside the station approach decision function:
   - `QIKI_SENSOR_MIN_QUALITY`, default `0.5`
   - `QIKI_SENSOR_MAX_AGE_S`, default `2.0`

ORION V also has freshness-like projection thresholds:

- `COMMS_AGE_WARN_S = 10.0`
- `COMMS_AGE_CRIT_S = 30.0`

These ORION thresholds are not QIKI legality thresholds. They are operator-view projection thresholds.

## 3. Definitions

### Freshness threshold

A numeric limit for data age or data quality. After this limit, the data is no longer trusted for a specific decision.

Examples:

- IMU data older than `2.5s` is stale for QIKI attitude stabilization.
- Comms data older than `3.0s` is stale for QIKI station hail reasoning.
- Station track age over `2.0s` is stale for station approach trust.

### Freshness gate

The decision point where freshness changes behavior.

Examples:

- stale IMU -> QIKI returns `deferred` and does not emit a stabilization command;
- stale comms -> QIKI returns `deferred` and does not emit a comms command;
- stale station track -> QIKI returns `deferred` and does not change guidance state.

### Threshold owner

The code/config contour allowed to define the threshold value and its intended meaning.

For this slice, the owner should be Q-Core/QIKI reasoning config, not ORION V and not q-sim-service.

### Operator projection

Human-facing interpretation for the cockpit. ORION V may show `fresh`, `aging`, `stale`, `commandable`, or `degraded`, but it must not become the authority for QIKI legality/trust decisions.

### ACK

A command-response confirmation that the command consumer accepted/applied the command and published a response envelope.

ACK is not the same as telemetry effect.

### Telemetry effect

The later observable world/simulation state that proves the command changed the world as expected.

Example: after `sim.dock.release`, telemetry confirms `docking.state == undocked` and `connected == false`.

## 4. Ownership table

| Category | Current threshold | Current owner path | Current behavior | Correct owner classification |
|---|---:|---|---|---|
| IMU freshness | stale `2.5s`, expire `10.0s` | local constants in `qiki_orion_intents_service.py` | stale IMU defers attitude stabilization and emits no control command | Q-Core/QIKI reasoning freshness gate |
| Comms freshness | stale `3.0s`, expire `12.0s` | local constants in `qiki_orion_intents_service.py` | stale comms defers station hail and emits no comms command | Q-Core/QIKI reasoning freshness gate |
| Resume objective retention | stale `90.0s` | local constant in `qiki_orion_intents_service.py` | old resume-observation candidates are skipped | Q-Core objective retention gate |
| Station track trust | max age `2.0s`, min quality `0.5` | `os.getenv(...)` inside station approach decision | stale/low-quality track defers approach and keeps guidance unchanged | Q-Core/QIKI reasoning freshness and quality gate |
| ORION data freshness display | warn `10.0s`, crit `30.0s` | `hardware_view_model/thresholds.py` imported by `operator_state.py` | link/status/commandability/data-freshness projection changes | ORION V operator projection only |
| Direct action ACK wait | `2.0s` | ORION V app execution flow | no ACK -> failed; ACK without effect -> pending | command execution timing, not data freshness |
| Procedure completion wait | `6.0s` | ORION V app execution flow | procedure not ok in time -> failed | procedure timing, not data freshness |
| Procedure telemetry effect wait | `3.0s` | ORION V app execution flow | procedure ok but effect missing -> pending | effect confirmation timing, not data freshness |
| q-sim command ACK | no freshness threshold | `q_sim_service/grpc_server.py` control consumer | applies/rejects command and publishes ACK | runtime command acceptance, not QIKI freshness policy |

## 5. Code evidence

### Q-Core freshness constants

`src/qiki/services/q_core_agent/qiki_orion_intents_service.py` currently defines:

- `_COMMS_STALE_AFTER_S = 3.0`
- `_COMMS_EXPIRE_AFTER_S = 12.0`
- `_IMU_STALE_AFTER_S = 2.5`
- `_IMU_EXPIRE_AFTER_S = 10.0`
- `_RESUME_OBJECTIVE_STALE_AFTER_S = 90.0`

### Shared Q-Core freshness classifier

`_section_freshness(...)` accepts:

- `section`
- `stale_after_s`
- `expire_after_s`
- optional `now_ts`

It returns `absent`, `stale`, or `fresh`. Important nuance: `expire_after_s` does not produce a separate public `expired` state today; it still maps to `stale`.

### IMU gate

QIKI attitude stabilization reads sensor freshness through `_section_freshness(...)` with `_IMU_STALE_AFTER_S` and `_IMU_EXPIRE_AFTER_S`.

When IMU is stale, QIKI returns a degraded trust signal with `reason_code="IMU_STATE_STALE"`, does not produce proposals, and states that no stabilization request or control-bus command was emitted while IMU freshness was insufficient.

### Comms gate

QIKI station hail uses `_section_freshness(...)` with `_COMMS_STALE_AFTER_S` and `_COMMS_EXPIRE_AFTER_S`.

When comms is stale, QIKI returns a degraded trust signal with `reason_code="COMMS_STATE_STALE"`, does not produce proposals, and states that no communication request was emitted while freshness was insufficient.

### Station track gate

Station approach does not use the same local constant path. It reads:

- `QIKI_SENSOR_MIN_QUALITY`, default `0.5`
- `QIKI_SENSOR_MAX_AGE_S`, default `2.0`

inside the decision function. If track age exceeds max age or quality falls below min quality, QIKI defers the action and keeps guidance unchanged.

### ORION V projection gate

`operator_state.py` imports `COMMS_AGE_WARN_S` and `COMMS_AGE_CRIT_S` from `hardware_view_model/thresholds.py`.

Those thresholds drive operator-facing `link_status`, `commandability_state`, `data_freshness_state`, alert/chip presentation. They do not own QIKI legality.

### ACK and effect path

ORION execution separates:

- ACK wait: `_wait_for_ack(..., 2.0)`;
- direct telemetry effect wait: `_wait_for_qiki_effect(..., 2.0)`;
- procedure completion wait: `_wait_for_procedure_completion(..., 6.0)`;
- procedure telemetry effect wait: `_wait_for_procedure_effect(..., 3.0)`.

q-sim-service builds and publishes command ACK envelopes after applying/rejecting a control command. q-sim-service owns world mutation and ACK result, not QIKI freshness policy.

## 6. Proposed ownership contract

One explicit Q-Core freshness ownership contour should own QIKI reasoning thresholds for this slice.

Suggested contract name:

- `QikiFreshnessPolicy`

Suggested contents:

- `imu_stale_after_s = 2.5`
- `imu_expire_after_s = 10.0`
- `comms_stale_after_s = 3.0`
- `comms_expire_after_s = 12.0`
- `resume_objective_stale_after_s = 90.0`
- `station_track_max_age_s = 2.0`
- `station_track_min_quality = 0.5`

Suggested owner path:

- a small config/policy module in the Q-Core agent contour;
- QIKI reasoning reads one policy object;
- env overrides, if kept, are loaded once into that policy object, not read ad-hoc inside decision functions.

Hard invariant for first implementation pass:

- values stay identical;
- result statuses stay identical;
- reason codes stay identical;
- no new gameplay contour;
- no ORION V projection threshold is promoted to QIKI legality owner.

## 7. Fault campaign spec for later proof

These are the narrow cases the implementation pass should prove after ownership normalization.

### Case 1: stale IMU

Input condition:

- sensor plane/IMU age exceeds `2.5s`.

Expected behavior:

- QIKI attitude stabilization returns `deferred`;
- trust signal includes `IMU_STATE_STALE`;
- no stabilization/control-bus command is emitted.

### Case 2: stale comms

Input condition:

- comms age exceeds `3.0s`.

Expected behavior:

- station hail returns `deferred`;
- trust signal includes `COMMS_STATE_STALE`;
- no comms command is emitted.

### Case 3: stale station track

Input condition:

- station track age exceeds `2.0s`.

Expected behavior:

- station approach returns `deferred`;
- consequence says tracking is stale;
- guidance state remains unchanged.

### Case 4: low-quality station track

Input condition:

- station track quality below `0.5`.

Expected behavior:

- station approach returns `deferred`;
- trust/legality explains insufficient quality;
- no approach guidance command is emitted.

### Case 5: delayed ACK

Input condition:

- command published, no matching ACK within ORION wait timeout.

Expected behavior:

- direct action/procedure execution fails or remains pending according to existing execution path;
- this is reported as command execution timing, not sensor freshness.

### Case 6: ACK without telemetry effect

Input condition:

- ACK arrives, but telemetry effect does not appear in time.

Expected behavior:

- consequence becomes `pending`;
- this is reported as effect confirmation pending, not freshness failure.

## 8. What not to implement in this slice

Do not:

- change threshold values;
- add a new sensor-driven gameplay path;
- promote ORION V UI thresholds into Q-Core legality;
- make q-sim-service owner of QIKI freshness policy;
- merge ACK timeout/procedure timeout/sensor freshness into one generic threshold system;
- create a second canon/config owner next to the current code without removing the old ownership ambiguity;
- repair live Docker stack as part of this design pass.

## 9. Implementation direction for next pass

The next practical implementation pass should do exactly this:

1. Add one Q-Core freshness policy object/module.
2. Move current QIKI reasoning threshold values into it without changing values.
3. Replace local constants and ad-hoc `os.getenv(...)` reads with policy access.
4. Keep ORION V projection thresholds unchanged and explicitly separate.
5. Run targeted Docker-first tests from the task dossier.
6. Update docs/task evidence and memory.

## 10. Current status

This artifact closes the read-only spec pass.

It does not claim runtime green. The last audit found the live stack was not proven green. Runtime proof belongs to the implementation pass after the ownership normalization patch.
