# Handoff 2026-04-27 - OPUI Introspector Visibility and Live Sync

## Scope

This handoff captures the current truthful state after investigating why Introspector evidence was not visible in the LangGraph operator web UI, validating the bridge live, and implementing a read-only evidence block in OPUI.

Trust rule for this handoff:

- current code + live HTTP/session state > this document
- this handoff is operational transfer support, not current truth owner

## What Was Actually Proven

### 1. The backend bridge code already existed in the repo

Previously implemented bridge files in `/home/sonra44/langgraph_app`:

- `app/introspector_report.py`
- `app/graph.py`
- `app/operator_ui.py`
- `app/ui_normalizer.py`
- tests around report/operator-ui flow

The correct canonical claim remains:

- LangGraph backend/OPUI can consume Introspector `/report/{project_name}` as `evidence_only`
- Introspector report must not set:
  - `approval_status`
  - `safe_to_proceed`
  - `judge_decision`
  - routing
  - command authority

### 2. The visible gap was real, but caused by stale live processes first

Old live stack on main ports:

- backend `127.0.0.1:2047` pid `3435038`, started `2026-04-26`
- OPUI `127.0.0.1:8092` pid `3434758`, started `2026-04-26`

Live check against this old stack proved:

- on approval stage, `technical.introspector_report` was `null`
- `normalized.report.evidence_basis` was empty

So the old running stack did not reflect the latest bridge work.

### 3. Fresh isolated stack proved the bridge works

Fresh isolated stack launched:

- analyzer `127.0.0.1:8015` pid `3778500`
- fresh LangGraph backend `127.0.0.1:2147` pid `3779448`
- fresh OPUI `127.0.0.1:8093` pid `3779508`

Factual Introspector scan run:

- project: `INTROSPECTOR_DEMO`
- modules scanned: `29`
- runtime events: `0`
- enrichment: absent

Fresh OPUI thread used for proof:

- thread id: `af0f2a7a-099d-454f-b8f5-7d43d03642c1`

Live session proof on approval stage:

- `approval_pending = true`
- `approval_status = pending`
- `technical.introspector_report.status = ok`
- report authority = `evidence_only`
- `safe_to_proceed = false`
- `judge_decision = ""`

Evidence lines present in normalized report:

- `Introspector report: modules=29, scan_errors=0, runtime_events=0`
- `Introspector enrichment: status=absent, findings=0, authority=evidence_only`

Limits present:

- `Introspector limit: runtime_absent`
- `Introspector limit: enrichment_absent`

Conclusion:

- the bridge logic works on fresh current code
- human approval boundary is preserved
- no automatic approval or authority bleed was observed

### 4. The second gap was true UX timing, not trust logic

Even when evidence was present in `normalized.report`, the operator still would not see it early enough because:

- the relevant data lived in `normalized.report`
- the main visible `result-card` is not the primary approval-stage surface

So evidence existed in state but was not surfaced in the right operator moment.

## Changes Made In This Session

Files changed in `/home/sonra44/langgraph_app/web`:

- `index.html`
- `app.js`
- `styles.css`

### UI change

Added a dedicated read-only Introspector evidence block directly inside the plan card, before approval actions.

Design intent:

- visible during approval stage
- clearly diagnostic / evidence-only
- no authority semantics
- shows:
  - status
  - authority
  - updated-at
  - evidence lines
  - report limits

### Exact file roles

- `web/index.html`
  - new `introspector-card` block with evidence/limits lists
- `web/app.js`
  - binds new elements
  - summarizes introspector report packet
  - renders block only when introspector content is actually present
- `web/styles.css`
  - styles the block as a diagnostic evidence panel

## Validation Done

### Local checks

Passed:

- `node --check /home/sonra44/langgraph_app/web/app.js`
- `python /home/sonra44/langgraph_app/scripts/test_introspector_report.py`
- `python /home/sonra44/langgraph_app/scripts/test_analysis_flow.py`
- `python /home/sonra44/langgraph_app/scripts/test_operator_ui_approval_flow.py`
- `python /home/sonra44/langgraph_app/scripts/test_ui_normalizer.py`

### Live UI asset checks

Confirmed from `http://127.0.0.1:8093/`:

- HTML contains `introspector-card`
- HTML contains `Evidence only`
- HTML contains the headings for evidence and limits

Confirmed from `http://127.0.0.1:8093/app.js`:

- JS contains the new `introspectorCard` render path
- JS contains `summarizeIntrospector`

### Live operator-flow proof

Fresh stack session on `8093` proved:

- approval is still pending
- introspector evidence is already present before approval
- introspector remains `evidence_only`

## Current Live Processes

### Old stale main-port stack

- `127.0.0.1:2047` -> pid `3435038` -> old langgraph dev
- `127.0.0.1:8092` -> pid `3434758` -> old OPUI

These are still running and still matter because they are the likely source of user confusion.

### Fresh proof stack

- `127.0.0.1:8015` -> pid `3778500` -> introspector analyzer
- `127.0.0.1:2147` -> pid `3779448` -> fresh langgraph dev
- `127.0.0.1:8093` -> pid `3779508` -> fresh OPUI

## Important Interpretation

The current truthful statement is:

- "Introspector evidence is available in current LangGraph/OPUI code and was proven live on the fresh isolated stack."

The current truthful non-claim is:

- do not say "the main user-facing web stack is already synchronized" until `2047/8092` is replaced or restarted and re-verified

## Risks / Drift Signals

1. The user may still be looking at old main ports `2047/8092`, where the stale process can hide the new behavior.
2. If a new agent reads only the old thread or old ports, it may falsely conclude the bridge is still missing.
3. Browser-visual proof was not captured as a screenshot in this session; verification was via live HTTP/session payload and served HTML/JS.
4. Memory was not updated in this session due environment policy constraints; this handoff is the persistence artifact.

## Exact Next Step

Do not present options unless the user explicitly asks for a branch.

Next exact step:

1. stop or replace the stale main-port stack on `2047/8092`
2. relaunch current code on the main ports
3. re-run the same approval-stage smoke against main ports
4. confirm that:
   - introspector evidence is visible on the approval-stage operator surface
   - `approval_pending` stays true
   - `safe_to_proceed` remains false before approval
   - no `judge_decision` appears from Introspector

## Useful Commands

### Introspector factual setup

```bash
cd /home/sonra44/QIKI_DTMP/introspector
ALLOW_DEGRADED_START=1 PYTHON_BIN=.venv/bin/python ./scripts/run_fresh_analyzer.sh
.venv/bin/python scripts/scan_project.py --project-name INTROSPECTOR_DEMO
```

### Fresh isolated proof stack

```bash
cd /home/sonra44/langgraph_app
source .venv/bin/activate
langgraph dev --no-reload --port 2147
GRAPH_API_BASE_URL=http://127.0.0.1:2147 python scripts/run_operator_ui.py --port 8093
```

### Main smoke request

```text
Сравни состояние introspector по отчёту и текущей задаче, дай план без выполнения
```

## Files Most Relevant For Resume

- `/home/sonra44/QIKI_DTMP/TASK_OUT/HANDOFF_20260427_LANGGRAPH_INTROSPECTOR_BRIDGE.md`
- `/home/sonra44/QIKI_DTMP/TASK_OUT/HANDOFF_20260427_OPUI_INTROSPECTOR_VISIBILITY_AND_SYNC.md`
- `/home/sonra44/langgraph_app/app/introspector_report.py`
- `/home/sonra44/langgraph_app/app/graph.py`
- `/home/sonra44/langgraph_app/app/operator_ui.py`
- `/home/sonra44/langgraph_app/app/ui_normalizer.py`
- `/home/sonra44/langgraph_app/web/index.html`
- `/home/sonra44/langgraph_app/web/app.js`
- `/home/sonra44/langgraph_app/web/styles.css`

## Final State Summary

Where we really stopped:

- root cause proved
- stale live stack identified
- fresh live stack proved the bridge
- approval-stage visibility gap fixed in OPUI
- local tests and live HTTP smoke passed
- main ports are not yet synchronized to the fresh proven code
