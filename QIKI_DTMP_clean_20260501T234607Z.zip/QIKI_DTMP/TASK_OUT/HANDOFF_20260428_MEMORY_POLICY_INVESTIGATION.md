# Handoff 2026-04-28 - Memory Policy Investigation

## Current State

This snapshot preserves the current investigation state around the memory write block seen by Codex in some sessions.

Important boundary:

- This file is a local persistence artifact only.
- It is not a substitute for Sovereign Memory.
- Current repo/runtime evidence remains above this handoff.

## What Was Proven

### 1. Serena is not the source of the block

Direct forced checks confirmed:

- `mcp__serena__.get_current_config()` succeeds.
- Active project is `QIKI_DTMP`.
- Serena reports active tools including:
  - `write_memory`
  - `edit_memory`
  - `delete_memory`
  - `read_memory`
  - `list_memories`

Conclusion:

- Serena is live.
- Serena is not in a read-only memory mode.
- Serena itself does not explain the `Never update memories. You can only read them.` block.

### 2. Sovereign Memory is not the source of the block

Forced checks confirmed:

- `~/.codex/config.toml` points Sovereign Memory MCP to `http://127.0.0.1:8000/mcp`
- process is alive:
  - `uvicorn server:app --host 127.0.0.1 --port 8000`
- port `8000` is listening
- MCP reads succeed:
  - `load_context(project="QIKI_DTMP", include_server=true, limit_per_topic=2)`
  - `recall_by_tags(project="QIKI_DTMP", topic="STATUS", limit=2)`

Conclusion:

- Sovereign Memory server is alive.
- Read-path works.
- Local config does not define a write prohibition.
- Sovereign Memory itself does not explain the session-level read-only memory block.

### 3. Local Codex config does not prohibit memory writes

Checked local `~/.codex/config.toml`:

- `memories = true`
- `mcp_servers.sovereign-memory` configured normally
- `mcp_servers.sovereign-memory.tools.add_memory.approval_mode = "approve"`

Conclusion:

- local config enables memory support
- local config does not impose the read-only block

### 4. Current Codex launch path is direct, not a local wrapper

Observed process chain:

- `tmux`
- `bash`
- `node .../bin/codex`
- vendor binary `.../vendor/x86_64-unknown-linux-musl/codex/codex`

No direct local launch wrapper was proven between shell and Codex for the current session.

### 5. The installed Codex binary contains memory-policy and injected-instructions machinery

Sub-investigation of local installed Codex package found:

- JS package is only a thin launcher.
- Real behavior lives in the vendor binary.
- The vendor binary contains:
  - `developer_instructions`
  - `baseInstructions`
  - `instructionSources`
  - `include_permissions_instructions`
  - memory-mode machinery
  - the exact string:
    - `Never update memories. You can only read them.`

Conclusion:

- local Codex supports external injected instructions
- local Codex supports memory mode logic
- the read-only memory sentence is built into the Codex binary as an instruction template / policy resource

### 6. Session artifacts prove the block is injected into some sessions

Session logs in `~/.codex/sessions/...jsonl` show injected developer/session blocks such as:

- `<permissions instructions>`
- `<collaboration_mode>`
- `<skills_instructions>`
- and, in some sessions, a memory section containing:
  - `Never update memories. You can only read them.`

Important observation:

- this memory block does not appear in every session
- therefore it is not a constant machine-wide immutable local setting
- it is a profile / instruction layer applied only to some runs

## Hard Conclusion

At this point the strongest truthful conclusion is:

- Serena is not the blocker
- Sovereign Memory is not the blocker
- local `~/.codex/config.toml` is not the blocker
- the current write prohibition is coming from an injected session/developer instruction layer that Codex accepts at runtime

## What Is Still Not Fully Proven

Not yet fully isolated:

- the exact upstream source that injects the memory read-only profile for this session class

Candidate source classes still open:

- external orchestration layer
- app / broker style launch path
- upstream session constructor outside local project config

## Safe Next Investigation Step

Do not act without explicit instruction.

Next exact analytical step:

1. create one fresh clean Codex session by the plainest possible manual launch path
2. inspect its earliest `rollout-*.jsonl`
3. compare against a session that carries the memory read-only block
4. identify which launch/source metadata diverges

## Relevant Artifacts

- `/home/sonra44/QIKI_DTMP/TASK_OUT/HANDOFF_20260427_OPUI_INTROSPECTOR_VISIBILITY_AND_SYNC.md`
- `/home/sonra44/QIKI_DTMP/TASK_OUT/HANDOFF_20260427_LANGGRAPH_INTROSPECTOR_BRIDGE.md`
- `/home/sonra44/QIKI_DTMP/TASK_OUT/HANDOFF_20260428_MEMORY_POLICY_INVESTIGATION.md`

## Final Note

User requested durable preservation of content/context.

In this session, direct MCP-memory writes are still blocked by the same investigated session-policy layer.
Therefore preservation for now is being done via local handoff artifacts under `TASK_OUT`.
