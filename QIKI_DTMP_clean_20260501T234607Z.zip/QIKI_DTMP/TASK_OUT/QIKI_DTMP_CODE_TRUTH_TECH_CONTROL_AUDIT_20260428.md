# QIKI_DTMP Code Truth Technical-Control Audit - 2026-04-28

Status: read-only code-fact report. This is not canon by itself and does not override current code/runtime evidence.

## Purpose

This report records the current code-truth picture of QIKI_DTMP as a technical-control system. The primary object is `/home/sonra44/QIKI_DTMP`, not introspector and not LANGGRAPH_APP.

Trust layer:

1. Current code and live runtime facts are highest.
2. This report is a TASK_OUT evidence summary.
3. Introspector and `space-ml-sim` are reference/evidence layers only.

## QIKI_DTMP Current Code Truth

- Main runtime contour in code: `q-sim-service` produces simulation/telemetry truth; `q-core-intents` builds QIKI legality/trust/consequence responses; `operator-console` / ORION V displays and confirms operator actions.
- Canonical NATS subjects are in `src/qiki/shared/nats_subjects.py`: telemetry `qiki.telemetry`, control `qiki.commands.control` / `qiki.responses.control`, QIKI intents/responses, operator events/objectives/combat.
- QSim owns real control toggles through `QSimService.apply_control_command` in `src/qiki/services/q_sim_service/service.py`: `sim.start`, `sim.pause`, `sim.stop`, `sim.reset`, `sim.dock.*`, `sim.rcs.*`, `sim.xpdr.mode`, power toggles.
- Control ACK path exists in `src/qiki/services/q_sim_service/grpc_server.py`: it listens on `COMMANDS_CONTROL`, applies command, publishes response envelope to `RESPONSES_CONTROL` with `request_id`, `success/ok`, `kind`, `payload.command_name/status`, and structured `error_detail` on failure.
- ORION V does not execute QIKI action immediately: it requires human confirmation, then publishes control command, waits for matching ACK, and separately waits for telemetry effect. Relevant area: `src/qiki/services/operator_console/orion_v/app.py` around pending action confirmation/execution.
- Procedure engine is a real ordered command/ACK runner: `src/qiki/services/operator_console/orion_v/procedure_engine.py` publishes each command, waits for expected ACK, and abort/continue depends on `on_fail`.
- Real procedures exist in `config/orion_v/procedures/`, including `safe_pause_resume.json`, `safe_pause_slow_resume.json`, and `hostile_rcs_intercept_burst.json`.
- QIKI legality/trust layer is not just chat: `src/qiki/services/q_core_agent/qiki_orion_intents_service.py` builds `QikiChatResponseV1` with legality status/domain/reason codes, trust signals, consequence, proposals/actions.
- Freshness exists, but ownership is split: hardcoded `_COMMS_STALE_AFTER_S=3.0`, `_IMU_STALE_AFTER_S=2.5`, `_RESUME_OBJECTIVE_STALE_AFTER_S=90.0` in `qiki_orion_intents_service.py`; station-track gate reads `QIKI_SENSOR_MIN_QUALITY` and `QIKI_SENSOR_MAX_AGE_S` from environment.
- Freshness semantics are functional: timestamp/age parsing treats future skew and absent data explicitly; stale data blocks or defers IMU/comms decisions.
- ORION operator projection computes commandability/data freshness: replay disables commandability, offline blocks, aged telemetry degrades; freshness states include `fresh`, `aging`, `stale`.

## Active Runtime / Technical-Control Contour

Expected code launch contour:

- `docker-compose.phase1.yml` starts NATS, q-sim, q-bios, FastStream bridge, q-core-intents, registrar.
- `docker-compose.operator.yml` starts ORION V through `python main_orion_v.py`.
- `scripts/run_orion_v_live.sh` is the canonical TTY launch path and uses `docker-compose.phase1.yml + docker-compose.operator.yml`, then `docker compose exec operator-console python main_orion_v.py`.

Live fact reported by the read-only audit:

- The phase1/operator stack was not green at the time of audit.
- `qiki-qcore-intents-phase1` was restarting.
- NATS, q-sim, operator-console, q-bios, and qiki-dev were exited.
- q-core-intents was failing on `GrpcDataProvider(config.grpc_server_address)` due to DNS failure for `q-sim-service:50051`, because q-sim was not up/resolvable in the current compose runtime.

Current runtime conclusion:

- The code contour for technical control exists.
- The live stack should not be claimed green until restarted and smoke-proven.
- Do not claim “ORION/QIKI live controls simulation right now” from code alone.

## Where Introspector Fits

Introspector is appropriate as an external evidence/reference layer:

- factual scan;
- runtime evidence;
- module inventory;
- optional enrichment after factual scan.

Introspector is not a QIKI_DTMP truth owner:

- it does not produce telemetry truth;
- it does not confirm ACK;
- it does not decide legality;
- it does not own operator authority;
- it must not replace `q_sim_service`, `q_core_intents`, ORION V, or NATS subject contracts.

Current introspector tool fact:

- `LG_INTROSPECTOR_8015` is live;
- `/report/INTROSPECTOR_DEMO` describes introspector self-scan at `/home/sonra44/QIKI_DTMP/introspector/src`;
- it has `modules_scanned=29`, runtime event count `1`, enrichment absent.

This proves the tool path, not QIKI_DTMP `/src`.

## space-ml-sim Ideas vs QIKI Reality

Reference report: `/home/sonra44/langgraph_app/artifacts/SPACE_ML_SIM_RESEARCH_REPORT_20260428.md`.

Ideas that fit QIKI_DTMP as concepts:

- `truth core -> environment effects -> derived metrics -> operator projection` maps well to QIKI: `WorldModel/QSimService` truth, telemetry payload, QIKI legality/trust, ORION operator projection.
- Fixed-step/tick discipline is relevant because QSim already has a tick loop, but commands currently appear to apply immediately in `apply_control_command`. “Commands only on tick boundary” is a future hardening idea, not current truth.
- Freshness fault campaigns fit the existing code because stale telemetry, dropped/delayed ACK, comms/IMU freshness gates, and request-id ACK matching already exist.
- “Freshness budget”, “confidence budget”, and “command legality budget” are useful vocabulary, but no single budget object currently owns them.
- Risk/stale-state heatmaps may fit ORION operator projection later, but should not precede ownership cleanup.

Ideas that do not fit as direct integration:

- Do not import or vendor `space-ml-sim`; it is AGPL, heavy, experimental, and its claimed GitHub repo returned 404 during research.
- Do not treat its orbit/radiation/ML-fault models as QIKI truth.
- Do not add torch/plotly/sgp4 dependencies to QIKI just for inspiration.

## What Already Looks Like Technical Control

- Command bus: `qiki.commands.control` and `qiki.responses.control`.
- Human-in-the-loop: QIKI proposal -> ORION pending action -> operator confirm -> command publish -> ACK -> telemetry effect.
- Legality gate: QIKI returns allowed/deferred/blocked, reason codes, allowed_when, consequences.
- Freshness gate: station track age/quality, comms freshness, IMU freshness, resume objective age.
- Operator projection: ORION V shows authority, telemetry age, commandability, link status, pending command count, action required.
- Simulation/control loop: QSim tick loop, `WorldModel`, telemetry publisher, event publisher, control command consumer.
- Procedure control: JSON procedures with command, expected ACK, timeout, abort/continue behavior.

## Open Tails / Risks

- Live stack is currently not green; runtime claims require a compose repair/startup smoke.
- Freshness threshold ownership is split between hardcoded constants and env-driven station-track gates.
- Control legality and execution are not a single policy object: QIKI legality lives in intent service; QSim command acceptance lives in QSim; ORION confirmation/ACK/effect wait lives in operator app.
- ACK confirms command application, not necessarily physical outcome; telemetry effect checks must remain action-specific.
- `space-ml-sim` must stay reference-only.
- Introspector must not become QIKI truth-owner.

## Next One Practical Step

Recommended next code-grounded step:

Prepare a read-only design/spec pass for `freshness threshold ownership` before implementation.

Exact evidence targets:

- `src/qiki/services/q_core_agent/qiki_orion_intents_service.py`: hardcoded comms/IMU/resume thresholds, `_section_freshness`, station-track env gate with `QIKI_SENSOR_MIN_QUALITY` and `QIKI_SENSOR_MAX_AGE_S`.
- `src/qiki/services/operator_console/orion_v/operator_state.py`: operator freshness/commandability projection.
- `src/qiki/services/operator_console/orion_v/app.py`: pending action confirmation, ACK wait, telemetry effect wait.
- `src/qiki/services/q_sim_service/grpc_server.py` and `service.py`: control command acceptance and ACK envelope.

Expected output of the next step:

- Define ownership of each freshness threshold.
- Decide which values remain hardcoded policy constants and which become env/config/runtime policy.
- Map each freshness gate to affected operator actions.
- Produce a small fault-campaign spec: stale comms, stale IMU, stale station track, delayed ACK, missing telemetry effect.

Do not implement until this design/spec pass is complete.

## What Not To Do Next

- Do not continue LANGGRAPH/introspector bridge as the main path for QIKI technical-control truth.
- Do not run provider enrichment as if it solves QIKI code ownership.
- Do not claim live ORION/QIKI behavior until phase1/operator stack is repaired and smoke-proven.
- Do not import/copy `space-ml-sim`.
- Do not start UI heatmap work before freshness ownership is clarified.
- Do not merge QIKI truth with introspector reports.
